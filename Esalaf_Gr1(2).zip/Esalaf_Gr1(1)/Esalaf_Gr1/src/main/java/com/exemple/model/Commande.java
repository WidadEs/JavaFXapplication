package com.exemple.model;

public class Commande {

    private Long id_commande ;

    private String prix ;

    private String destinataire ;

    public Commande(long idCommande, String text, String desText) {
    }

    public Commande(Long id_commande, String prix, String destinataire) {
        this.id_commande = id_commande;
        this.prix = prix;
        this.destinataire = destinataire;
    }

    public static void clear() {
    }

    public static void clear(Object fetchAll) {
    }

    public static void addAll(Object fetchAll) {
    }

    public Long getId_commande() {
        return id_commande;
    }

    public void setId_commande(Long id_commande) {
        this.id_commande = id_commande;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public String getDestinataire() {
        return destinataire;
    }

    public void setDestinataire(String destinataire) {
        this.destinataire = destinataire;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "id_commande=" + id_commande +
                ", prix='" + prix + '\'' +
                ", destinataire='" + destinataire + '\'' +
                '}';
    }
}
