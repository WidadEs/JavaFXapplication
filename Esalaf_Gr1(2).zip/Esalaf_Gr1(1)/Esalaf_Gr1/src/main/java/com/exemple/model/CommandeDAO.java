package com.exemple.model;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeDAO extends  BaseDAO<Commande> {
    Connection con;
    {
        con = null;
    }

    public CommandeDAO() throws SQLException {
        super();
    }

    // mapping objet --> relation
    @Override
    public void save(Commande object) throws SQLException {

        String req = "insert into commande (prix , destinataire) values (? , ?) ;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1 , object.getPrix());
        this.preparedStatement.setString(2 , object.getDestinataire());
        this.preparedStatement.execute();
    }
    // function update
    @Override
    public boolean update(Commande object) throws SQLException {
        String req = "update commande set prix = ?, destinataire = ? where id_commande = ?;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1, object.getPrix());
        this.preparedStatement.setString(2, object.getDestinataire());
        this.preparedStatement.setLong(3, object.getId_commande());
        return this.preparedStatement.execute();
    }
    // function delete
    @Override
    public boolean delete(Commande object) throws SQLException {
        String req = "DELETE FROM commande WHERE id_commande = ? AND prix = ? AND destinataire = ?";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1, object.getId_commande());
        this.preparedStatement.setString(2, object.getPrix());
        this.preparedStatement.setString(3, object.getDestinataire());
        return this.preparedStatement.execute();
    }
    @Override
    public Commande getOne(Long id) throws SQLException {
        return null;
    }
    // mapping relation --> objet
    @Override
    public List<Commande> getAll() throws SQLException{

        List<Commande> mylist = new ArrayList<Commande>();
        String req = " select * from commande" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

            mylist.add( new Commande(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3)));
        }

        return mylist;
    }

    @Override
    public Object fetchAll() {
        return null;
    }

    public Connection getConnection() {
        return connection;
    }


}