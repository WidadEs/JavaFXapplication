package com.exemple.model;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public  class ProduitDAO extends  BaseDAO<Produit> {
    Connection con;
    {
        con = null;
    }

    public ProduitDAO() throws SQLException {
        super();
    }

    // mapping objet --> relation
    @Override
    public void save(Produit object) throws SQLException {

        String req = "insert into produit (Nom , Quantité) values (? , ?) ;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1 , object.getNomproduit());
        this.preparedStatement.setString(2 , object.getQuantité());
        this.preparedStatement.execute();
    }



    // function update
    @Override
    public boolean update(Produit object) throws SQLException {
        String req = "update produit set Nom = ?, Quantité = ? where idp = ?;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1, object.getNomproduit());
        this.preparedStatement.setString(2, object.getQuantité());
        this.preparedStatement.setLong(3, object.getId_produit());
        return this.preparedStatement.execute();
    }
    // function delete
    @Override
    public boolean delete(Produit object) throws SQLException {
        String req = "DELETE FROM produit WHERE idp = ? AND Nom = ? AND Quantité = ?";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1, object.getId_produit());
        this.preparedStatement.setString(2, object.getNomproduit());
        this.preparedStatement.setString(3, object.getQuantité());
        return this.preparedStatement.execute();
    }
    @Override
    public Produit getOne(Long id) throws SQLException {
        return null;
    }
    // mapping relation --> objet
    @Override
    public List<Produit> getAll() throws SQLException{

        List<Produit> mylist = new ArrayList<Produit>();
        String req = " select * from produit" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

            mylist.add( new Produit(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3)));
        }

        return mylist;
    }

    @Override
    public Object fetchAll() {
        return null;
    }

    public Connection getConnection() {
        return connection;
    }


}
