package com.exemple.model;


// java beans (Entity)
public class Produit {

    private Long id_produit ;

    private String nomproduit ;

    private String quantité ;

    public Produit(long idProduit, String text, String qText) {
    }

    public Produit(Long id_produit, String nomproduit, String quantité) {
        this.id_produit = id_produit;
        this.nomproduit = nomproduit;
        this.quantité = quantité;
    }

    public static void clear() {
    }

    public static void clear(Object fetchAll) {
    }

    public static void addAll(Object fetchAll) {
    }

    public Long getId_produit() {
        return id_produit;
    }

    public void setId_produit(Long id_produit) {
        this.id_produit = id_produit;
    }

    public String getNomproduit() {
        return nomproduit;
    }

    public void setNomproduit(String nom) {
    }

    public String getQuantité() {
        return quantité;
    }

    public void setQuantité(String quantité) {
        this.quantité = quantité;
    }

    @Override
    public String toString() {
        return "Produit{" +
                "id_produit=" + id_produit +
                ", nomproduit='" + nomproduit + '\'' +
                ", quantité='" + quantité + '\'' +
                '}';
    }
}
