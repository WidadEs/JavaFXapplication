package com.example.esalaf;

import com.exemple.model.Commande;
import com.exemple.model.CommandeDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CommandeController implements Initializable {

    Connection con = null;
    private CommandeDAO commandeDAO;
    @FXML
    private TextField idd;

    @FXML
    private TextField des;
    //----------------------------------
    @FXML
    private Button ok4;

    @FXML
    private Button ok6;

    @FXML
    Button showproduit;
    @FXML
    private Button ok5;
    private Commande selectedcommande;
    //-----------------------------------
    @FXML
    private TableView<Commande> mytab2;

    @FXML
    private TableColumn<Commande, Long> cola;

    @FXML
    private TableColumn<Commande, Integer> colb;

    @FXML
    private TableColumn<Commande, String> colc;
    private Object object;
    @FXML
    Button returnee;

    public CommandeController() {
    }

    @FXML
    protected void onSaveButtonClicka(){
        Commande com = new Commande(0l , idd.getText() , des.getText());
        try {
            CommandeDAO comdao = new CommandeDAO();
            comdao.save(com);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable2();
    }

    public void UpdateTable2(){
        cola.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id_commande"));
        colb.setCellValueFactory(new PropertyValueFactory<Commande, Integer>("prix"));
        colc.setCellValueFactory(new PropertyValueFactory<Commande,String>("destinataire"));
        mytab2.setItems(getDataCommandes());
    }

    public static ObservableList<Commande> getDataCommandes(){
        CommandeDAO comdao = null;
        ObservableList<Commande> listfx = FXCollections.observableArrayList();
        try {
            comdao = new CommandeDAO();
            for(Commande ettemp : comdao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @FXML
    void onUpdateButtonClickb() {
        Commande selectedcommande = mytab2.getSelectionModel().getSelectedItem();
        if(selectedcommande != null){
            try {
                CommandeDAO comdao = new CommandeDAO();
                selectedcommande.setPrix(idd.getText());
                selectedcommande.setDestinataire(des.getText());
                boolean update1;
                if (comdao.update(selectedcommande)) {
                    update1 = true;
                } else {
                    update1 = false;
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            UpdateTable2();
        }
    }
    @FXML
    void onDeleteButtonClickc() {
        Commande selectedCommande = mytab2.getSelectionModel().getSelectedItem();
        if (selectedCommande != null) {
            try {
                CommandeDAO comdao = new CommandeDAO();
                comdao.delete(selectedCommande);
                UpdateTable2();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable2();

    }

    public void tableclientClickeda(MouseEvent mouseEvent) {
        selectedcommande = mytab2.getSelectionModel().getSelectedItem();
        if( selectedcommande != null){
            idd.setText(selectedcommande.getPrix());
            des.setText(selectedcommande.getDestinataire());
            ok4.setDisable(false);
            ok5.setDisable(false);
          ok6.setDisable(false);
        }


    }
    private void resetClient (){
        idd.clear();
        des.clear();
        selectedcommande = null;
        ok4.setDisable(false);
        ok5.setDisable(true);
        ok6.setDisable(true);
    }
    public void rproduit() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("showproduit.fxml"));
        Stage Window = (Stage) returnee.getScene().getWindow();
        Window.setScene(new Scene(fxmlLoader.load() , 500,500));
    }
}
