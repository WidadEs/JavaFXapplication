package com.example.esalaf;

import com.exemple.model.Produit;
import com.exemple.model.ProduitDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class produitController implements Initializable {
    Connection con = null;
    private ProduitDAO produitDAODAO;
    @FXML
    private TextField np;

    @FXML
    private TextField q;
    //----------------------------------
    @FXML
    private Button ok1;

    @FXML
    private Button ok2;


    @FXML
    private Button ok3;
    private Produit selectedproduit;
    //-----------------------------------
    @FXML
    private TableView<Produit> mytab1;

    @FXML
    private TableColumn<Produit, Long> col1;

    @FXML
    private TableColumn<Produit, String> col2;

    @FXML
    private TableColumn<Produit, String> col3;
    private Object object;
    @FXML
    Button returne;

    @FXML
    Button cmd;

    public produitController() {
    }

    @FXML
    protected void onSaveButtonClick1(){
        Produit pro = new Produit(0l , np.getText() , q.getText());
        try {
            ProduitDAO prodao = new ProduitDAO();
            prodao.save(pro);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable1();
    }

    public void UpdateTable1(){
        col1.setCellValueFactory(new PropertyValueFactory<Produit,Long>("id_produit"));
        col2.setCellValueFactory(new PropertyValueFactory<Produit,String>("nomproduit"));
        col3.setCellValueFactory(new PropertyValueFactory<Produit,String>("quantité"));
        mytab1.setItems(getDataClients1());
    }

    public static ObservableList<Produit> getDataClients1(){
        ProduitDAO prodao = null;
        ObservableList<Produit> listfx = FXCollections.observableArrayList();
        try {
            prodao = new ProduitDAO();
            for(Produit ettemp : prodao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @FXML
    void onUpdateButtonClick1() {
        Produit selectedproduit = mytab1.getSelectionModel().getSelectedItem();
        if(selectedproduit != null){
            try {
                ProduitDAO prodao = new ProduitDAO();
                selectedproduit.setNomproduit(np.getText());
                selectedproduit.setQuantité(q.getText());
                boolean update11;
                if (prodao.update(selectedproduit)) {
                    update11 = true;
                } else {
                    update11 = false;
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            UpdateTable1();
        }
    }

    @FXML
    void onDeleteButtonClick1() {
        Produit selectedProduit = mytab1.getSelectionModel().getSelectedItem();
        if (selectedProduit != null) {
            try {
                ProduitDAO prodao = new ProduitDAO();
                prodao.delete(selectedProduit);
                UpdateTable1();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable1();

    }


    public void tableclientClicked1(MouseEvent mouseEvent) {
        selectedproduit = mytab1.getSelectionModel().getSelectedItem();
        if( selectedproduit != null){
            np.setText(selectedproduit.getNomproduit());
            q.setText(selectedproduit.getQuantité());
            ok1.setDisable(false);
            ok2.setDisable(false);
            ok3.setDisable(false);
        }


    }

    private void resetProduit (){
        np.clear();
        q.clear();
        selectedproduit = null;
        ok1.setDisable(false);
        ok2.setDisable(true);
        ok3.setDisable(true);
    }
    public void handlebtn2() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Stage Window = (Stage) returne.getScene().getWindow();
        Window.setScene(new Scene(fxmlLoader.load() , 500,500));
    }

    public void showcmd() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("showcommande.fxml"));
        Stage Window = (Stage) cmd.getScene().getWindow();
        Window.setScene(new Scene(fxmlLoader.load() , 500,500));
    }
}
