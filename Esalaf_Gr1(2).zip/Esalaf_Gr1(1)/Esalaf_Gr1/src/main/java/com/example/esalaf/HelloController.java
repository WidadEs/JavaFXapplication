package com.example.esalaf;

import com.exemple.model.Client;
import com.exemple.model.ClientDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    Connection con = null;
    private ClientDAO clientDAO;
    @FXML
    private TextField nom;

    @FXML
    private TextField tele;
    //----------------------------------
    @FXML
    private Button ok;

    @FXML
    private Button Delet;

    @FXML
    Button showproduit;
    @FXML
    private Button update;
    private  Client selectedclient;
    //-----------------------------------
    @FXML
    private TableView<Client> mytab;

    @FXML
    private TableColumn<Client, Long> col_id;

    @FXML
    private TableColumn<Client, String> col_nom;

    @FXML
    private TableColumn<Client, String> col_tele;
    private Object object;



    public HelloController() {
    }

    //-------------------------------------------------------------------------------------------
    //saveClient
    @FXML
    protected void onSaveButtonClick(){
        Client cli = new Client(0l , nom.getText() , tele.getText());
        try {
            ClientDAO clidao = new ClientDAO();
            clidao.save(cli);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }
    //pour view de client dans la table
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Client,Long>("id_client"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Client,String>("nom"));
        col_tele.setCellValueFactory(new PropertyValueFactory<Client,String>("telepehone"));
        mytab.setItems(getDataClients());
    }

    public static ObservableList<Client> getDataClients(){
        ClientDAO clidao = null;
        ObservableList<Client> listfx = FXCollections.observableArrayList();
        try {
            clidao = new ClientDAO();
            for(Client ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }
    //-------------------------------------------------------------------------------------
    //update
    @FXML
    void onUpdateButtonClick() {
        Client selectedclient = mytab.getSelectionModel().getSelectedItem();
        if(selectedclient != null){
            try {
                ClientDAO clidao = new ClientDAO();
                selectedclient.setNom(nom.getText());
                selectedclient.setTelepehone(tele.getText());
                boolean update1;
                if (clidao.update(selectedclient)) {
                    update1 = true;
                } else {
                    update1 = false;
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            UpdateTable();
        }
    }
    //------------------------------------------------------------------------------------
    //delete
    @FXML
    void onDeleteButtonClick() {
        Client selectedClient = mytab.getSelectionModel().getSelectedItem();
        if (selectedClient != null) {
            try {
                ClientDAO clidao = new ClientDAO();
                clidao.delete(selectedClient);
                UpdateTable();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    //-----------------------------------------------------------------
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
    //----------------------------------------------------------------------------
    // pour selectioner un client table
    public void tableclientClicked(MouseEvent mouseEvent) {
        selectedclient = mytab.getSelectionModel().getSelectedItem();
        if( selectedclient != null){
            nom.setText(selectedclient.getNom());
            tele.setText(selectedclient.getTelepehone());
            ok.setDisable(false);
            update.setDisable(false);
            Delet.setDisable(false);
        }


    }
    // pour les button
    private void resetClient (){
        nom.clear();
        tele.clear();
        selectedclient = null;
        ok.setDisable(false);
        update.setDisable(true);
        Delet.setDisable(true);
    }

    public void handlebtn1() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("showproduit.fxml"));
        Stage Window = (Stage) showproduit.getScene().getWindow();
        Window.setScene(new Scene(fxmlLoader.load() , 500,500));
    }
}